package com.example.aqbahinventoryapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.InventoryCallbacks {

    private InventoryRepository repository;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private final List<InventoryItem> items = new ArrayList<>();

    private static final String DEFAULT_SMS_TARGET = "5556";

    private final ActivityResultLauncher<Intent> addItemLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> refreshList());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        repository = new InventoryRepository(this);

        recyclerView = findViewById(R.id.rvInventory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new InventoryAdapter(items, this);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAddItem);
        fab.setOnClickListener(v -> addItemLauncher.launch(new Intent(this, AddItemActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
    }

    private void refreshList() {
        items.clear();
        items.addAll(repository.getAllItems());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onDeleteClicked(InventoryItem item) {
        if (repository.deleteItem(item.getId())) {
            Toast.makeText(this, "Deleted " + item.getName(), Toast.LENGTH_SHORT).show();
            refreshList();
        } else {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRowClicked(InventoryItem item) {
        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint("New quantity");
        input.setText(String.valueOf(item.getQuantity()));

        new AlertDialog.Builder(this)
                .setTitle("Update Quantity")
                .setMessage("Set quantity for: " + item.getName())
                .setView(input)
                .setPositiveButton("Save", (DialogInterface dialog, int which) -> {
                    String txt = input.getText().toString().trim();
                    if (txt.isEmpty()) {
                        Toast.makeText(this, "Quantity is required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int newQty;
                    // Defensive Programming: Catch invalid number formats
                    try {
                        newQty = Integer.parseInt(txt);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (newQty < 0) {
                        Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (repository.updateQuantity(item.getId(), newQty)) {
                        InventoryItem updated = repository.getItem(item.getId());
                        if (updated != null && updated.getQuantity() <= updated.getThreshold()) {
                            maybeSendLowInventorySms(updated);
                        }
                        refreshList();
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void maybeSendLowInventorySms(InventoryItem item) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsUtils.sendLowInventorySms(this, DEFAULT_SMS_TARGET, item);
            Toast.makeText(this, "Low inventory alert sent via SMS", Toast.LENGTH_SHORT).show();
        }
    }
}