package com.example.aqbahinventoryapp;

import android.content.Context;
import android.telephony.SmsManager;

public class SmsUtils {

    public static void sendLowInventorySms(Context ctx, String phone, InventoryItem item) {
        if (item == null || phone == null || phone.trim().isEmpty()) {
            return;
        }

        String msg = "Low inventory alert: " + item.getName() +
                " (Qty: " + item.getQuantity() + ", Threshold: " + item.getThreshold() + ")";

        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, msg, null, null);
        } catch (Exception ignored) {
            // Managed gracefully at activity level
        }
    }
}